function [ema_a, ema_b, ema_a_star, Neff_star] = compute_ab_ema(Neff, a_series, b_series)
p = Neff/(1+Neff)
N_window = length(a_series)
ema_a = conv(ema(Neff, N_window), a_series - a_series(1)) + a_series(1)
ema_a = ema_a(1:N_window)
ema_b = conv(ema(Neff, N_window), b_series - b_series(1)) + b_series(1)
ema_b = ema_b(1:N_window)
ab_series = a_series .* b_series
ema_ab = conv(ema(Neff, N_window), ab_series - ab_series(1)) + ab_series(1)
ema_ab = ema_ab(1:N_window)
ema_a_star = ema_ab ./ ema_b
Neff_star = zeros(N_window,1)
for i = 2:N_window
    p_star = p * ema_b(i-1)/ema_b(i)
    Neff_star(i) = p_star /(1-p_star)
end

end