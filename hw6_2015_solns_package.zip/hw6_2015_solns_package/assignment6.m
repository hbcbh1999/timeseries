data = csvread('jpm_quotes.csv',1,1)
px = data(:,1)
intensity = data(:,2)
Neff = 20
[ema_px, ema_intensity, ema_px_star, Neff_star] = compute_ab_ema(Neff, px, intensity)

figure
subplot(3,2,1)
plot(1:length(px), [px,ema_px,ema_px_star])
title('Prices')
legend('price', 'emaPrice', 'VWAP', 'location', 'Southeast')


subplot(3,2,2)
plot(1:length(intensity), intensity)
title('Intensity')

subplot(3,2,3)
plot(1:length(Neff_star), Neff_star)
title('NeffStar')

subplot(3,2,4)
plot(1:length(Neff_star), cumsum(Neff_star))
title('CDF of NeffStar')

subplot(3,2,5)
scatter(intensity(2:length(intensity)),Neff_star(2:length(Neff_star)))
title('Scatter Plot')

figure
plot(1:length(ema_intensity), ema_intensity)
title('emaIntensity')