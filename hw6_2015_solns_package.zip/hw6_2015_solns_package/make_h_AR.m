function y = make_h_AR(params, Nwindow)

% descrip: returns the AR3 equation

lags_y = length(params) - 1;

y_tilde = zeros(Nwindow + lags_y, 1);

for i = lags_y + 1 : length(y_tilde)
    y_tilde(i) = params(1);
    
    for j = 2 : length(params)
        y_tilde(i) = y_tilde(i) + params(j) * y_tilde(i - j + 1);
    end
end

y = y_tilde(lags_y + 1:end);

end

