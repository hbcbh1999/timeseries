% script:  study_AR.m
% descrip: hw6 problem a: analysis of an AR(3) Equation
% author:  Weiyi Chen, Rongxin Yu
% note: Please *run section* one by one

% We are going to convert this FDE into its impulse response, reconcile
% a numerically computed impulse response with the analytically derived
% response, and plot the pole-zero diagram to analyze stability.

params = [0.0047, 0.35, 0.18, -0.14];

%% (b) 
% Find and report the roots of Q(z). Are any roots degenerate?
disp('(b) Find and report the roots of Q(z):')
ls_coef = [1 -0.35 -0.18 0.14];
root = roots(ls_coef);
disp(root)

%% (c) 
% Generate a pole-zero diagram plot of Q^{-1}(z). Make sure you draw a
% unit circle so that the stability or lack thereof is clear.

disp('(c) Generate a pole-zero diagram plot of Q^{-1}(z):')
z = [0 0 0]';
zplane(z, root);

%% (d)
% Multiply through by Q^{?1}(z). Use partial-fraction expansion to write 
% H(z) in terms of simple polynomials of the roots of Q(z). Don?t report 
% the numeric pole and residue values in your written result, use pi, Ai 
% and Ci as necessary. Of course you?ll have these values in your code.

disp('(d) Multiply through by Q^{?1}(z):')
[ls_residue,ls_pole,direct] = residuez([1,0,0,0],ls_coef);

A_1 = ls_residue(1);
A_2 = ls_residue(2);
A_3 = ls_residue(3);

p_1 = ls_pole(1);
p_2 = ls_pole(2);
p_3 = ls_pole(3);

%% (f)
% For each pole of Q(z) convert the root value to the first-moment Neff
% of an appropriate impulse shape. Use |pi| if a root is complex.

disp('(f) Convert the root value to the first-moment Neff of an appropriate impulse shape:')
moment_1 = abs(p_1) / (1 - abs(p_1))^2;
moment_2 = abs(p_2) / (1 - abs(p_2))^2;
moment_3 = abs(p_3) / (1 - abs(p_3))^2;

%% (g)
% On an axis n = [0 : 10Neff] compute and plot h[n], const h[n] * u[n],
% and their sum.

disp('(g) Compute and plot h[n], const h[n] * u[n], and their sum:');

% first plot data
Neff = max([moment_1, moment_2, moment_3]);
n = (0 : round(10 * Neff))';
h = A_1*(p_1).^n + A_2*(p_2).^ n + A_3*(p_3).^n;

% 2nd plot data
u = ones(round(10 * Neff) + 1, 1);
hu_n = params(1) * conv(h, u);
hu_n = hu_n(1:length(h));

% 3rd plot data
sum_n = h + hu_n;

% plots
figure;

subplot(3,1,1);
plot(n, h);
title('h[n]');

subplot(3,1,2);
plot(n, hu_n);
title('const h[n] * u[n]');

subplot(3,1,3);
plot(n, sum_n);
title('sum');

%% (h)
% Following the method from the last homework, compute the impulse
% response of the AR(3) recursion equation. Set the initial conditions
% to zero. Denote this response y[n]. Plot this response, and overlay it
% with y[n] of (3). (You might have to adjust the delay ? I did.) The
% analytic and computed impulse responses should exactly match.

disp('(h) Compute and plot the impulse response of the AR(3) recursion equation:');

y_n = make_h_AR(params, length(n));

figure;
plot(n, y_n, 'b-*'); hold on;
plot(n, hu_n, 'r');
hold off;

%% (i)
% Compute the gain in two ways: that from H(z) and that from h[n].
% Report your results.

disp('(i) Compute the gain in two ways:');

gain_1 = 1 / (sum(ls_coef));
gain_2 = sum(h);

disp('from H[z] - ');
disp(gain_1)
disp('from h[n] - ');
disp(gain_2);